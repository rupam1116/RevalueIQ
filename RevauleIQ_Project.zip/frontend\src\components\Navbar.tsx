"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Menu, X, Leaf, Search, Wrench, Package, MapPin, ArrowRight, Sparkles, Compass, ShieldCheck, Recycle, BarChart3, HelpCircle, DollarSign, Layers, Info, ShoppingBag } from "lucide-react";
import { Button } from "./ui/button";
import { UserButton, useAuth } from "@clerk/nextjs";
import { ThemeToggle } from "./ThemeToggle";

const navLinks = [
  { name: "Home", path: "/" },
  { name: "Features", path: "/features" },
  { name: "How It Works", path: "/how-it-works" },
  { name: "Marketplace", path: "/marketplace" },
  { name: "Repair Shops", path: "/repair-shops" },
  { name: "Donation", path: "/donation-centres" },
  { name: "Pricing", path: "/pricing" },
  { name: "Dashboard", path: "/dashboard" },
  { name: "About", path: "/about" },
];

// Comprehensive Platform Index for Instant Search Across the Entire RevalueIQ Ecosystem
const platformIndex = [
  { title: "AI Device Appraisal & Valuation", category: "Core Feature", path: "/upload", icon: ShieldCheck, desc: "Upload photos for AI condition grading and instant resale value prediction", keywords: "appraise upload value estimate price sell ai vision grade photo camera scan smartphone laptop ev" },
  { title: "Refurbished Tech Marketplace", category: "Marketplace", path: "/marketplace", icon: ShoppingBag, desc: "Buy and sell verified pre-owned electronics and electric vehicles with warranty", keywords: "buy sell shop marketplace store refurbished secondhand used iphone macbook laptop ev scooter phone" },
  { title: "Certified Repair Shops & Service Centers", category: "Repairs", path: "/repair-shops", icon: Wrench, desc: "Find local authorized service centers and EV workshops via OpenStreetMap live geocoding", keywords: "repair shop service center fix screen broken battery mechanic ather ola tvs apple samsung lg appliance workshop" },
  { title: "E-Waste Donation & Recycling Hub", category: "Sustainability", path: "/donation-centres", icon: Recycle, desc: "Locate certified e-waste drop-off points for safe disposal and green rewards", keywords: "donate donation recycle recycling ewaste e-waste dropoff disposal green carbon environment old broken scrap" },
  { title: "Sustainability & Carbon Dashboard", category: "Analytics", path: "/dashboard", icon: BarChart3, desc: "Track your CO2 emissions saved, e-waste diverted, and circular economy impact", keywords: "dashboard analytics carbon co2 impact footprint sustainability savings rewards profile stats" },
  { title: "Platform Features & AI Technology", category: "Platform", path: "/features", icon: Layers, desc: "Explore AI pricing models, blockchain verification, and circular tech capabilities", keywords: "features ai tech capability pricing model vision circular economy innovation" },
  { title: "How RevalueIQ Works", category: "Guide", path: "/how-it-works", icon: HelpCircle, desc: "Step-by-step guide to appraising, repairing, reselling, and recycling electronics", keywords: "how it works guide help tutorial process steps instruction onboarding faq" },
  { title: "Pricing & Membership Plans", category: "Platform", path: "/pricing", icon: DollarSign, desc: "Free tier for individuals, Pro for repair shops, and Enterprise for recyclers", keywords: "pricing cost subscription plan pro free enterprise membership fee business" },
  { title: "About Our Mission", category: "Company", path: "/about", icon: Info, desc: "Our mission to eliminate e-waste and empower the sustainable electronics circular economy", keywords: "about mission story team company contact vision goal ewaste" },
];

const popularQueries = [
  { label: "📱 iPhones & Smartphones", query: "Smartphone" },
  { label: "💻 Laptops & MacBooks", query: "Laptop" },
  { label: "🛵 Electric Scooters (EVs)", query: "Electric Scooter" },
  { label: "🏠 Home Appliances", query: "Washing Machine" },
  { label: "♻️ Recycle Old Tech", query: "Recycle" },
  { label: "🤖 Calculate Resale Value", query: "Appraise" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const pathname = usePathname();
  const router = useRouter();
  const { isSignedIn } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Filter platform items based on query
  const trimmedQuery = searchQuery.trim().toLowerCase();
  const filteredResults = trimmedQuery
    ? platformIndex.filter(item => 
        item.title.toLowerCase().includes(trimmedQuery) ||
        item.desc.toLowerCase().includes(trimmedQuery) ||
        item.keywords.includes(trimmedQuery) ||
        item.category.toLowerCase().includes(trimmedQuery)
      )
    : [];

  const handleSelectPath = (path: string) => {
    setSearchModalOpen(false);
    setSearchQuery("");
    router.push(path);
  };

  const handleGlobalSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trimmedQuery) return;
    
    // If exact match in platform index, go there
    if (filteredResults.length > 0) {
      handleSelectPath(filteredResults[0].path);
    } else {
      // Otherwise default to searching marketplace / repair shops for that product
      setSearchModalOpen(false);
      setSearchQuery("");
      router.push(`/repair-shops?product=${encodeURIComponent(trimmedQuery)}`);
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 w-full z-50 transition-all duration-300 print:hidden ${
          scrolled
            ? "bg-white/80 dark:bg-slate-900/80 backdrop-blur-md shadow-sm border-b border-border/50"
            : "bg-transparent"
        }`}
      >
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Left: Logo */}
            <Link href="/" className="flex items-center gap-2 group">
              <div className="bg-primary/10 p-2 rounded-xl group-hover:bg-primary/20 transition-colors">
                <Leaf className="w-6 h-6 text-primary" />
              </div>
              <span className="font-poppins font-bold text-2xl tracking-tight text-foreground">
                Revalue<span className="text-primary">IQ</span>
              </span>
            </Link>

            {/* Middle: Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) => {
                const isActive = pathname === link.path;
                return (
                  <Link
                    key={link.name}
                    href={link.path}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                      isActive
                        ? "bg-primary/10 text-primary font-semibold"
                        : "text-muted-foreground hover:bg-slate-100 hover:text-foreground dark:hover:bg-slate-800"
                    }`}
                  >
                    {link.name}
                  </Link>
                );
              })}
            </nav>

            {/* Right: Actions */}
            <div className="hidden lg:flex items-center gap-3">
              {/* Functional Global Platform Search Button */}
              <button 
                onClick={() => setSearchModalOpen(true)}
                title="Search RevalueIQ Platform"
                className="flex items-center gap-2 px-3.5 py-2 rounded-full bg-slate-100 dark:bg-slate-800 text-muted-foreground hover:text-foreground hover:bg-slate-200 dark:hover:bg-slate-700 transition-all border border-border/50 shadow-sm group cursor-pointer"
              >
                <Search className="w-4 h-4 text-primary group-hover:scale-110 transition-transform" />
                <span className="text-xs font-medium pr-1">Search RevalueIQ...</span>
                <kbd className="hidden xl:inline-block text-[10px] bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded border border-border font-mono text-muted-foreground">⌘K</kbd>
              </button>

              <ThemeToggle />
              <div className="h-6 w-px bg-border mx-1"></div>
              {isSignedIn && (
                <UserButton />
              )}
              {!isSignedIn && (
                <>
                  <Link href="/login" className="text-sm font-medium text-foreground hover:text-primary transition-colors px-2">
                    Login
                  </Link>
                  <Link href="/signup">
                    <Button className="rounded-full bg-gradient-to-r from-primary via-teal-500 to-accent text-white border-0 hover:opacity-90 shadow-md shadow-primary/25 text-sm font-semibold px-5">
                      Sign Up
                    </Button>
                  </Link>
                </>
              )}
            </div>

            {/* Mobile Menu Toggle & Actions */}
            <div className="lg:hidden flex items-center gap-2">
              <button 
                onClick={() => setSearchModalOpen(true)}
                className="p-2.5 rounded-full bg-slate-100 dark:bg-slate-800 text-foreground hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                title="Search RevalueIQ"
              >
                <Search className="w-5 h-5 text-primary" />
              </button>
              <ThemeToggle />
              <button
                className="p-2 text-foreground"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white dark:bg-slate-900 border-b border-border overflow-hidden shadow-2xl animate-in fade-in slide-in-from-top-4 duration-200">
              <div className="px-4 py-6 space-y-3 flex flex-col">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setSearchModalOpen(true);
                  }}
                  className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-primary/10 border border-primary/20 text-primary font-bold text-sm mb-2"
                >
                  <div className="flex items-center gap-2.5">
                    <Search className="w-5 h-5" />
                    <span>Search RevalueIQ Platform...</span>
                  </div>
                  <ArrowRight className="w-4 h-4" />
                </button>

                {navLinks.map((link) => (
                  <Link
                    key={link.name}
                    href={link.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`block px-4 py-2.5 text-base font-medium rounded-xl ${
                      pathname === link.path
                        ? "bg-primary/15 text-primary font-bold"
                        : "text-foreground hover:bg-slate-50 dark:hover:bg-slate-800"
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
                <div className="pt-4 border-t border-border flex flex-col gap-3">
                  {isSignedIn && (
                    <div className="flex justify-center p-2">
                      <UserButton />
                    </div>
                  )}
                  {!isSignedIn && (
                    <>
                      <Link href="/login" className="w-full" onClick={() => setMobileMenuOpen(false)}>
                        <Button variant="outline" className="w-full justify-center rounded-xl h-12">
                          Login
                        </Button>
                      </Link>
                      <Link href="/signup" className="w-full" onClick={() => setMobileMenuOpen(false)}>
                        <Button className="w-full justify-center bg-gradient-to-r from-primary to-accent text-white rounded-xl h-12 font-bold">
                          Sign Up
                        </Button>
                      </Link>
                    </>
                  )}
                </div>
              </div>
            </div>
          )}
      </header>

      {/* GLOBAL REVALUEIQ PLATFORM COMMAND PALETTE / SEARCH MODAL */}
      {searchModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-start justify-center pt-16 md:pt-24 px-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-3xl shadow-2xl border border-border/80 overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-200">
              {/* Search Modal Header */}
              <div className="p-6 border-b border-border bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-2xl bg-primary/10 text-primary">
                    <Search className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-poppins font-bold text-lg text-foreground">RevalueIQ Platform Search</h3>
                    <p className="text-xs text-muted-foreground">Search AI appraisals, marketplace, repairs, recycling & features</p>
                  </div>
                </div>
                <button
                  onClick={() => setSearchModalOpen(false)}
                  className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Search Input Box */}
              <form onSubmit={handleGlobalSearchSubmit} className="p-6 pb-4 shrink-0">
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search RevalueIQ (e.g. Appraise laptop, Marketplace, iPhone repair, Recycle)..."
                    autoFocus
                    className="w-full pl-12 pr-28 py-4 bg-slate-100 dark:bg-slate-800 rounded-2xl border-2 border-primary/30 focus:border-primary focus:outline-none focus:ring-4 focus:ring-primary/10 text-foreground font-medium text-base transition-all"
                  />
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-primary" />
                  <Button
                    type="submit"
                    className="absolute right-2 top-1/2 -translate-y-1/2 rounded-xl bg-primary hover:bg-primary/90 text-white font-bold text-sm px-5 h-11"
                  >
                    Search
                  </Button>
                </div>
              </form>

              {/* Scrollable Results / Shortcuts Area */}
              <div className="px-6 pb-6 overflow-y-auto space-y-6">
                {/* 1. Dynamic Search Results when typing */}
                {trimmedQuery && (
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-primary mb-3 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Matching Platform Features & Pages ({filteredResults.length})</span>
                    </label>
                    
                    {filteredResults.length > 0 ? (
                      <div className="space-y-2">
                        {filteredResults.map((item) => {
                          const IconComponent = item.icon;
                          return (
                            <div
                              key={item.path}
                              onClick={() => handleSelectPath(item.path)}
                              className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 hover:bg-primary/10 dark:hover:bg-primary/20 border border-border/60 hover:border-primary/40 flex items-center justify-between cursor-pointer transition-all group"
                            >
                              <div className="flex items-center gap-3">
                                <div className="p-2 rounded-xl bg-white dark:bg-slate-900 shadow-sm text-primary">
                                  <IconComponent className="w-5 h-5" />
                                </div>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <h4 className="font-bold text-sm text-foreground group-hover:text-primary transition-colors">{item.title}</h4>
                                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-muted-foreground">{item.category}</span>
                                  </div>
                                  <p className="text-xs text-muted-foreground mt-0.5">{item.desc}</p>
                                </div>
                              </div>
                              <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="p-6 text-center rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-dashed border-border">
                        <p className="text-sm font-medium text-foreground mb-3">No direct page match for "{searchQuery}"</p>
                        <div className="flex flex-wrap justify-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleSelectPath(`/repair-shops?product=${encodeURIComponent(searchQuery)}`)}
                            className="px-4 py-2 rounded-xl bg-orange-500/10 text-orange-600 dark:text-orange-400 text-xs font-bold hover:bg-orange-500/20 transition-colors flex items-center gap-1.5"
                          >
                            <Wrench className="w-3.5 h-3.5" />
                            <span>Find Repair Shops for "{searchQuery}"</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSelectPath(`/marketplace?search=${encodeURIComponent(searchQuery)}`)}
                            className="px-4 py-2 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 text-xs font-bold hover:bg-blue-500/20 transition-colors flex items-center gap-1.5"
                          >
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>Search Marketplace for "{searchQuery}"</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSelectPath(`/upload`)}
                            className="px-4 py-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold hover:bg-emerald-500/20 transition-colors flex items-center gap-1.5"
                          >
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>AI Appraise "{searchQuery}"</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* 2. Popular Search Queries when empty */}
                {!trimmedQuery && (
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      <span>Popular Search Topics</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {popularQueries.map((tag) => (
                        <button
                          key={tag.label}
                          type="button"
                          onClick={() => setSearchQuery(tag.query)}
                          className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-primary/10 hover:text-primary dark:hover:bg-primary/20 text-muted-foreground hover:border-primary/30 border border-transparent text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer"
                        >
                          <span>{tag.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* 3. RevalueIQ Core Ecosystem Quick Links */}
                {!trimmedQuery && (
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">
                      🚀 RevalueIQ Platform Navigation Hub
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {platformIndex.map((item) => {
                        const IconComponent = item.icon;
                        return (
                          <div
                            key={item.path}
                            onClick={() => handleSelectPath(item.path)}
                            className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 border border-border/60 hover:border-primary/40 flex items-start gap-3 transition-all group cursor-pointer"
                          >
                            <div className="p-2 rounded-xl bg-white dark:bg-slate-900 shadow-sm text-primary group-hover:bg-primary group-hover:text-white transition-colors shrink-0">
                              <IconComponent className="w-4 h-4" />
                            </div>
                            <div className="min-w-0">
                              <h4 className="font-bold text-xs text-foreground group-hover:text-primary transition-colors truncate">{item.title}</h4>
                              <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">{item.desc}</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
          </div>
        </div>
      )}
    </>
  );
}
