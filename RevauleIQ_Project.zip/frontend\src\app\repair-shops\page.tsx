'use client';

import React, { useState, useEffect } from "react";
import { Wrench, MapPin, Star, Phone, Search, Navigation, ShieldCheck, Laptop, Smartphone, Gamepad2, Watch, Tv, Cpu, RefreshCw, CheckCircle2, Package, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

const quickCategories = [
  { id: "All Products & Devices", label: "🛠️ All Products" },
  { id: "Mobile Phones & iPhones", label: "📱 Mobile Phones" },
  { id: "Laptops & MacBooks", label: "💻 Laptops" },
  { id: "Tablets & iPads", label: "📲 Tablets" },
  { id: "Smartwatches & Wearables", label: "⌚ Smartwatches" },
  { id: "Headphones & Earbuds", label: "🎧 Headphones" },
  { id: "Cameras & Optical", label: "📷 Cameras" },
  { id: "Televisions & Displays", label: "📺 Televisions" },
  { id: "Printers & Scanners", label: "🖨️ Printers" },
  { id: "Gaming Consoles", label: "🎮 Gaming Consoles" },
  { id: "Monitors & Displays", label: "🖥️ Monitors" },
  { id: "Speakers & Audio Systems", label: "🔊 Speakers" },
  { id: "Home Appliances & Kitchen", label: "🏠 Home Appliances" },
  { id: "Electric Scooters (Ola, Ather, TVS)", label: "🛵 Electric Scooters" },
  { id: "Electric Bikes (e-Bikes)", label: "🚲 Electric Bikes" },
  { id: "Electric Cars (EVs)", label: "🚗 Electric Cars" },
  { id: "Electric Buses & Commercial EVs", label: "🚌 Electric Buses" },
];

export default function RepairShopsPage() {
  const [location, setLocation] = useState<string>("Hyderabad, India");
  const [customProduct, setCustomProduct] = useState<string>("All Products & Devices");
  const [shops, setShops] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [locating, setLocating] = useState<boolean>(false);
  const [searchedLocation, setSearchedLocation] = useState<string>("Hyderabad, India");
  const [searchedProduct, setSearchedProduct] = useState<string>("All Products & Devices");

  const fetchShops = async (loc: string, prod: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/repair-shops/search?location=${encodeURIComponent(loc)}&product=${encodeURIComponent(prod)}`);
      const data = await res.json();
      if (data.success && data.shops) {
        setShops(data.shops);
        setSearchedLocation(data.location || loc);
        setSearchedProduct(data.product || prod);
      }
    } catch (err) {
      console.error("Failed to fetch repair shops:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleLocateMe = () => {
    if (typeof window === "undefined" || !navigator.geolocation) {
      alert("Geolocation is not supported by your browser.");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const { latitude, longitude } = pos.coords;
          const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`);
          const data = await res.json();
          if (data && data.address) {
            const addr = data.address;
            const city = addr.city || addr.town || addr.suburb || addr.state_district || "Hyderabad";
            const state = addr.state || "";
            const locStr = state ? `${city}, ${state}` : city;
            setLocation(locStr);
            fetchShops(locStr, customProduct);
          } else {
            setLocation("Hyderabad, India");
            fetchShops("Hyderabad, India", customProduct);
          }
        } catch (e) {
          console.error("Reverse geocoding error:", e);
        } finally {
          setLocating(false);
        }
      },
      (err) => {
        console.error("Geolocation error:", err);
        setLocating(false);
      },
      { timeout: 10000 }
    );
  };

  useEffect(() => {
    let initialProduct = customProduct;
    let initialLocation = "Hyderabad, India";

    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const prodParam = params.get("product") || params.get("device") || params.get("category");
      if (prodParam) {
        initialProduct = prodParam;
        setCustomProduct(prodParam);
      }
      const locParam = params.get("location") || params.get("city") || params.get("pincode");
      if (locParam) {
        initialLocation = locParam;
        setLocation(locParam);
      }
    }

    if (typeof window !== "undefined" && !new URLSearchParams(window.location.search).get("location")) {
      fetch("https://ipwho.is/")
        .then(res => res.json())
        .then(data => {
          if (data && data.success && data.city && data.region) {
            const autoLoc = `${data.city}, ${data.region}`;
            setLocation(autoLoc);
            fetchShops(autoLoc, initialProduct);
            return;
          }
        })
        .catch(() => {});
    }

    fetchShops(initialLocation, initialProduct);
  }, []);

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!location.trim() && !customProduct.trim()) return;
    fetchShops(location || "San Francisco, CA", customProduct || "All Products & Devices");
  };

  const handleQuickSelect = (catLabel: string) => {
    setCustomProduct(catLabel);
    fetchShops(location, catLabel);
  };

  return (
    <div className="min-h-screen pt-28 pb-20 bg-slate-50 dark:bg-slate-950 relative selection:bg-orange-500/20">
      {/* Background glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[450px] bg-gradient-to-b from-orange-500/10 via-amber-500/5 to-transparent blur-3xl pointer-events-none" />

      <div className="container mx-auto px-4 md:px-8 max-w-6xl relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-600 dark:text-orange-400 text-xs font-semibold mb-2 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
            <span>OpenStreetMap & Overpass API Live Geocoding Connected</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold font-poppins tracking-tight text-foreground">
            Local <span className="text-orange-500">Repair Shops</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mt-4">
            Search real existing certified repair professionals near you for <span className="font-bold text-foreground">any product or device type</span> to extend its lifecycle.
          </p>
        </div>

        {/* Search & Filter Hub */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 md:p-8 border-2 border-orange-500/20 shadow-xl mb-12">
          
          {/* Dual Search Form (Location + Custom Product) */}
          <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-8">
            
            {/* Product / Item Type Input */}
            <div className="md:col-span-5 relative">
              <label className="block text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2 px-1">
                1. What product do you need repaired?
              </label>
              <div className="relative">
                <Package className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-orange-500" />
                <input 
                  type="text" 
                  value={customProduct}
                  onChange={(e) => setCustomProduct(e.target.value)}
                  placeholder="e.g. iPhone 15, Espresso Machine, Sofa, DSLR Camera..." 
                  className="w-full pl-12 pr-4 py-3.5 rounded-2xl border border-border bg-slate-50 dark:bg-slate-800/80 focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium text-foreground text-sm sm:text-base transition-all"
                />
              </div>
            </div>

            {/* Location Input */}
            <div className="md:col-span-4 relative">
              <div className="flex items-center justify-between mb-2 px-1">
                <label className="block text-xs font-bold text-muted-foreground uppercase tracking-wider">
                  2. Your City or Zip Code
                </label>
                <button 
                  type="button" 
                  onClick={handleLocateMe}
                  disabled={locating}
                  className="text-[11px] font-bold text-orange-500 hover:text-orange-600 dark:hover:text-orange-400 flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <Navigation className={`w-3 h-3 ${locating ? "animate-spin" : ""}`} />
                  <span>{locating ? "Locating..." : "📍 Auto-Detect"}</span>
                </button>
              </div>
              <div className="relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-emerald-500" />
                <input 
                  type="text" 
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Hyderabad, Mumbai, or 500039..." 
                  className="w-full pl-12 pr-4 py-3.5 rounded-2xl border border-border bg-slate-50 dark:bg-slate-800/80 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium text-foreground text-sm sm:text-base transition-all"
                />
              </div>
            </div>

            {/* Search Submit Button */}
            <div className="md:col-span-3 flex items-end">
              <Button 
                type="submit" 
                disabled={loading}
                className="w-full rounded-2xl h-14 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-bold shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2 text-base"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    <span>Searching...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-5 h-5" />
                    <span>Find Shops</span>
                  </>
                )}
              </Button>
            </div>

          </form>

          {/* Quick Category Pills */}
          <div className="space-y-3 pt-2 border-t border-border/40">
            <div className="flex items-center justify-between text-xs font-semibold text-muted-foreground px-1">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-orange-500" />
                <span>QUICK SELECT PRODUCT CATEGORIES:</span>
              </span>
              <span className="text-orange-500 font-bold hidden sm:inline">Supports Any Custom Product</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {quickCategories.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => handleQuickSelect(cat.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                    customProduct === cat.id
                      ? "bg-orange-500 text-white shadow-md shadow-orange-500/25 font-bold scale-105"
                      : "bg-slate-100 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-border/40"
                  }`}
                >
                  <span>{cat.label}</span>
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Results Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6 px-2">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-xl md:text-2xl font-bold font-poppins text-foreground">
              {loading ? "Searching Overpass API & Live Directory..." : `Found ${shops.length} Certified Repair Specialists`}
            </h2>
            {!loading && (
              <span className="text-xs bg-orange-500/10 text-orange-600 dark:text-orange-400 font-semibold px-2.5 py-1 rounded-full border border-orange-500/20">
                for "{searchedProduct}" in {searchedLocation}
              </span>
            )}
          </div>
          <span className="text-xs text-muted-foreground flex items-center gap-1.5 bg-white dark:bg-slate-900 px-3 py-1 rounded-full border border-border/60 w-fit">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            Verified Overpass API & Live Geo-Data
          </span>
        </div>

        {/* Shops Grid / List */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-white/60 dark:bg-slate-900/60 rounded-3xl p-6 md:p-8 border border-border/40 animate-pulse h-48 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="h-6 bg-slate-200 dark:bg-slate-800 rounded w-1/3" />
                  <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-1/2" />
                </div>
                <div className="h-10 bg-slate-200 dark:bg-slate-800 rounded-xl w-full" />
              </div>
            ))}
          </div>
        ) : shops.length === 0 ? (
          <div className="text-center py-20 bg-white dark:bg-slate-900 rounded-3xl border border-border p-8">
            <Wrench className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-xl font-bold text-foreground mb-2">No Repair Shops Found</h3>
            <p className="text-muted-foreground max-w-md mx-auto mb-6">
              We couldn't find any specialized repair facilities matching "{searchedProduct}" in "{searchedLocation}". Try checking the spelling or searching for a broader category.
            </p>
            <Button onClick={() => handleQuickSelect("All Products & Devices")} className="rounded-xl bg-orange-500 hover:bg-orange-600">
              Show All General Shops
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {shops.map((shop) => (
              <div 
                key={shop.id} 
                className="bg-white dark:bg-slate-900 rounded-3xl p-6 md:p-8 border border-border/80 hover:border-orange-500/50 hover:shadow-xl transition-all duration-300 flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative overflow-hidden group"
              >
                {/* Accent stripe */}
                <div className="absolute top-0 left-0 w-1.5 h-full bg-gradient-to-b from-orange-500 to-amber-500 opacity-80 group-hover:opacity-100 transition-opacity" />

                <div className="flex-1 space-y-3 pl-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-xl md:text-2xl font-bold text-foreground group-hover:text-orange-500 transition-colors">
                      {shop.name}
                    </h3>
                    <span className="inline-flex items-center gap-1 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[11px] font-bold px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                      <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                      {shop.source?.includes("Overpass") ? "Overpass Live Verified" : "Verified Shop"}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-xs md:text-sm text-muted-foreground font-medium">
                    <span className="flex items-center text-foreground">
                      <MapPin className="w-4 h-4 mr-1 text-orange-500 shrink-0" /> 
                      {shop.address}
                    </span>
                    <span className="bg-slate-100 dark:bg-slate-800 px-2.5 py-0.5 rounded-md font-semibold text-orange-600 dark:text-orange-400 border border-border/40">
                      📍 {shop.distance}
                    </span>
                    <span className="text-xs text-slate-400">
                      🏢 {shop.source || "Live Directory"}
                    </span>
                  </div>

                  <p className="text-xs md:text-sm text-muted-foreground leading-relaxed line-clamp-2 max-w-3xl">
                    {shop.description}
                  </p>

                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {shop.specialties.map((spec: string, i: number) => (
                      <span 
                        key={i} 
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                          spec.toLowerCase().includes(searchedProduct.toLowerCase()) && searchedProduct !== "All Products & Devices"
                            ? "bg-orange-500 text-white shadow-sm font-bold"
                            : "bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border border-border/40"
                        }`}
                      >
                        ⚡ {spec}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 pt-1 text-sm font-bold text-amber-500">
                    <Star className="w-4 h-4 fill-amber-500" /> 
                    <span>{shop.rating}</span>
                    <span className="text-xs font-normal text-muted-foreground">({shop.reviews} verified reviews)</span>
                  </div>
                </div>

                <div className="flex flex-wrap sm:flex-nowrap lg:flex-col gap-3 shrink-0 pt-4 lg:pt-0 border-t lg:border-t-0 border-border/60">
                  <a 
                    href={`tel:${shop.phone}`} 
                    className="flex-1 sm:flex-initial"
                  >
                    <Button variant="outline" className="w-full lg:w-44 h-12 rounded-2xl border-2 border-border hover:border-orange-500/40 font-semibold gap-2">
                      <Phone className="w-4 h-4 text-orange-500" />
                      <span>{shop.phone}</span>
                    </Button>
                  </a>

                  <a 
                    href={shop.directionsUrl || shop.website} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex-1 sm:flex-initial"
                  >
                    <Button className="w-full lg:w-44 h-12 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-bold shadow-md shadow-orange-500/20 gap-2">
                      <Navigation className="w-4 h-4 text-white" />
                      <span>Directions</span>
                    </Button>
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Footer info box */}
        <div className="mt-16 p-8 rounded-3xl bg-slate-100 dark:bg-slate-900/60 border border-border text-center max-w-2xl mx-auto space-y-2">
          <h4 className="font-semibold text-sm text-foreground flex items-center justify-center gap-2">
            <ShieldCheck className="w-4 h-4 text-orange-500" />
            How OpenStreetMap & Overpass API Search Works
          </h4>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Our platform queries OpenStreetMap's live Overpass API and Nominatim geocoding engine to match certified repair facilities, craftsmen, and restoration studios with your exact product type (whether electronics, appliances, furniture, optical equipment, or musical instruments) in your specific city or zip code—100% free and open source.
          </p>
        </div>

      </div>
    </div>
  );
}