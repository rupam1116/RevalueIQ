import Link from "next/link";
import { Scan, Cpu, LineChart, Wrench, HandHeart, Recycle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const features = [
  { 
    icon: Scan, 
    title: "AI Product Verification", 
    description: "Instantly verify electronics category and make using advanced image recognition.",
    details: "Upload a single photo and our model automatically classifies the device, identifies the exact model, and checks for authenticity, saving you time and preventing listing errors."
  },
  { 
    icon: Cpu, // Reusing Cpu as a placeholder for Computer Vision/Camera
    title: "Computer Vision Damage Detection", 
    description: "Identify scratches, cracks, and defects with pinpoint accuracy.",
    details: "Our proprietary computer vision models highlight physical damage on the device's screen and casing, removing subjectivity from the grading process."
  },
  { 
    icon: LineChart, 
    title: "ML Price Prediction", 
    description: "Predict real-time market and resale value.",
    details: "We scrape millions of data points across the secondary market to provide an accurate, depreciated valuation for your specific device based on its detected condition."
  },
  { 
    icon: Wrench, 
    title: "Generative AI Repair Advisor", 
    description: "Get repair guides and estimated costs instantly.",
    details: "If a device is broken, our Generative AI suggests the required parts, estimates the repair cost, and provides step-by-step repair manuals to help you fix it."
  },
  { 
    icon: HandHeart, 
    title: "Donation Matching", 
    description: "Connect with NGOs to donate seamlessly.",
    details: "Devices with zero resale value but still functioning can be matched with local schools and NGOs, bridging the digital divide while preventing e-waste."
  },
  { 
    icon: Recycle, 
    title: "Carbon Savings Dashboard", 
    description: "Track your environmental impact.",
    details: "Every device you repair, sell, or donate reduces e-waste. We quantify your positive environmental impact in kg of CO2 saved, visualized beautifully on your dashboard."
  },
];

export default function FeaturesPage() {
  return (
    <div className="min-h-screen pt-28 pb-20 bg-slate-50 dark:bg-slate-950">
      <div className="container mx-auto px-4 md:px-8 max-w-6xl">
        
        <div className="text-center max-w-3xl mx-auto mb-20 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium border border-primary/20 mb-4">
            Next-Gen Technology
          </div>
          <h1 className="text-4xl md:text-6xl font-bold font-poppins tracking-tight text-foreground">
            Features that <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Empower</span>
          </h1>
          <p className="text-xl text-muted-foreground leading-relaxed mt-6">
            RevalueIQ combines computer vision, machine learning, and generative AI to completely automate the circular economy of electronics.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12 mb-20">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white dark:bg-slate-900 rounded-3xl p-8 lg:p-10 border border-border shadow-sm hover:shadow-xl hover:border-primary/20 transition-all duration-300"
            >
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-8">
                <feature.icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-4">{feature.title}</h3>
              <p className="text-lg font-medium text-slate-700 dark:text-slate-300 mb-4">
                {feature.description}
              </p>
              <p className="text-muted-foreground leading-relaxed">
                {feature.details}
              </p>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-br from-primary/10 via-primary/5 to-accent/10 rounded-3xl p-12 text-center border border-primary/20 shadow-sm relative overflow-hidden">
          <div className="relative z-10 max-w-2xl mx-auto space-y-6">
            <h2 className="text-3xl font-bold text-foreground">Ready to experience these features?</h2>
            <p className="text-lg text-muted-foreground">
              Stop guessing. Start knowing. Upload your first product today and let our AI do the heavy lifting.
            </p>
            <Link href="/upload" className="inline-block mt-4">
              <Button size="lg" className="rounded-full bg-primary hover:bg-primary/90 text-white h-14 px-8 text-lg">
                Start Your First Appraisal <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
        
      </div>
    </div>
  );
}