import Link from "next/link";
import { ArrowLeft, HeartHandshake, Leaf, Recycle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function DonationPage() {
  return (
    <div className="min-h-screen pt-28 pb-20 bg-slate-50 dark:bg-slate-950">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link href="/dashboard" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-green-500 transition-colors mb-2">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
            </Link>
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground">Donate & Recycle</h1>
            <p className="text-muted-foreground mt-2 text-lg">Give your devices a second life and reduce e-waste.</p>
          </div>
          <Button className="hidden md:flex rounded-full px-6 shadow-sm bg-green-500 hover:bg-green-600 text-white">
            <HeartHandshake className="w-4 h-4 mr-2" />
            Partner NGOs
          </Button>
        </div>

        {/* Coming Soon Placeholder */}
        <div className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-xl rounded-3xl border border-border p-12 text-center shadow-sm min-h-[400px] flex flex-col items-center justify-center relative overflow-hidden group">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-green-500/10 via-transparent to-transparent opacity-50"></div>
          
          <div className="w-24 h-24 bg-green-500/10 rounded-full flex items-center justify-center mb-6 relative z-10">
            <Recycle className="w-12 h-12 text-green-500" />
          </div>
          <h2 className="text-3xl font-bold mb-4 relative z-10 text-foreground">Green Initiatives Coming Soon!</h2>
          <p className="text-muted-foreground max-w-lg mx-auto text-lg mb-8 relative z-10">
            We are integrating with top NGOs and e-waste recycling centers. Soon, you can safely donate devices or recycle completely broken electronics for carbon credits.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 relative z-10">
            <Button size="lg" className="rounded-full px-8 h-12 bg-green-500 hover:bg-green-600 text-white shadow-md hover:scale-105 transition-transform">Get Updates</Button>
            <Link href="/upload">
              <Button size="lg" variant="outline" className="rounded-full px-8 h-12 bg-white dark:bg-slate-800">
                Appraise Another Device
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}