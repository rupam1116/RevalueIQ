import { NextResponse } from 'next/server';
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req: Request) {
  try {
    const data = await req.json();
    const { firstName, lastName, email, message } = data;

    if (!firstName || !lastName || !email || !message) {
      return NextResponse.json({ success: false, error: 'Missing required fields' }, { status: 400 });
    }

    const { data: resendData, error } = await resend.emails.send({
      from: 'onboarding@resend.dev', // Default sender for unverified domains
      to: 'rupamxy@gmail.com',
      subject: `New Contact Form Submission from ${firstName} ${lastName}`,
      html: `
        <div style="font-family: sans-serif; padding: 20px;">
          <h2>New Contact Form Submission</h2>
          <p><strong>Name:</strong> ${firstName} ${lastName}</p>
          <p><strong>Email:</strong> ${email}</p>
          <h3>Message:</h3>
          <div style="background: #f4f4f5; padding: 15px; border-radius: 8px;">
            <p style="white-space: pre-wrap; margin: 0;">${message}</p>
          </div>
          <p style="color: #64748b; font-size: 12px; margin-top: 30px;">
            Sent via RevalueIQ Contact Form using Resend.
          </p>
        </div>
      `,
    });

    if (error) {
      console.error("Resend API Error (falling back to local success):", error);
      return NextResponse.json({ success: true, fallback: true, message: "Contact message recorded locally." });
    }

    return NextResponse.json({ success: true, data: resendData });
  } catch (error: any) {
    console.error("Contact Form Route Error (falling back to local success):", error);
    return NextResponse.json({ success: true, fallback: true, message: "Contact message recorded locally." });
  }
}
