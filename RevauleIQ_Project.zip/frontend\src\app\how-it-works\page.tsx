import Link from "next/link";
import { Upload, Shield, Scan, LineChart, Wrench, Star, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const steps = [
  { 
    icon: Upload, 
    title: "1. Upload Images", 
    description: "Snap photos of your device from multiple angles. Our system accepts standard image formats.",
    color: "text-blue-500",
    bg: "bg-blue-100 dark:bg-blue-900/30"
  },
  { 
    icon: Shield, 
    title: "2. AI Verification", 
    description: "Our AI verifies the product model, make, and specifications automatically.",
    color: "text-indigo-500",
    bg: "bg-indigo-100 dark:bg-indigo-900/30"
  },
  { 
    icon: Scan, 
    title: "3. Damage Detection", 
    description: "Computer vision spots scratches, cracks, and dents, objectively grading the condition.",
    color: "text-purple-500",
    bg: "bg-purple-100 dark:bg-purple-900/30"
  },
  { 
    icon: LineChart, 
    title: "4. Price Prediction", 
    description: "Machine learning estimates the current resale value based on real-time market data.",
    color: "text-pink-500",
    bg: "bg-pink-100 dark:bg-pink-900/30"
  },
  { 
    icon: Wrench, 
    title: "5. Repair Advisory", 
    description: "Generative AI suggests repair steps and estimated costs if the device is damaged.",
    color: "text-orange-500",
    bg: "bg-orange-100 dark:bg-orange-900/30"
  },
  { 
    icon: Star, 
    title: "6. Decision Engine", 
    description: "Get the best recommendation: Repair, Sell, Donate, or Recycle, maximizing your value.",
    color: "text-teal-500",
    bg: "bg-teal-100 dark:bg-teal-900/30"
  },
];

export default function HowItWorksPage() {
  return (
    <div className="min-h-screen pt-28 pb-20 bg-slate-50 dark:bg-slate-950">
      <div className="container mx-auto px-4 md:px-8 max-w-5xl">
        
        <div className="text-center max-w-3xl mx-auto mb-20 space-y-4">
          <h1 className="text-4xl md:text-6xl font-bold font-poppins tracking-tight text-foreground">
            How It <span className="text-primary">Works</span>
          </h1>
          <p className="text-xl text-muted-foreground leading-relaxed mt-6">
            A seamless, 6-step process powered by Artificial Intelligence to maximize your electronics' value and minimize environmental impact.
          </p>
        </div>

        <div className="relative">
          {/* Vertical Line for Desktop */}
          <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-0.5 bg-border -translate-x-1/2"></div>
          
          <div className="space-y-12 md:space-y-0 relative">
            {steps.map((step, index) => {
              const isEven = index % 2 === 0;
              return (
                <div key={index} className={`flex flex-col md:flex-row items-center ${isEven ? 'md:flex-row-reverse' : ''} md:h-64 relative`}>
                  
                  {/* Empty half for spacing on desktop */}
                  <div className="hidden md:block md:w-1/2"></div>
                  
                  {/* Center Node */}
                  <div className="absolute left-1/2 -translate-x-1/2 w-16 h-16 rounded-full bg-white dark:bg-slate-900 border-4 border-slate-50 dark:border-slate-950 shadow-md flex items-center justify-center z-10 hidden md:flex">
                    <step.icon className={`w-6 h-6 ${step.color}`} />
                  </div>
                  
                  {/* Content Card */}
                  <div className={`w-full md:w-1/2 ${isEven ? 'md:pr-16 md:text-right' : 'md:pl-16 md:text-left'} text-center md:text-left`}>
                    <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-border shadow-sm hover:shadow-lg transition-shadow">
                      <div className={`w-14 h-14 mx-auto md:mx-0 ${isEven ? 'md:ml-auto' : ''} rounded-2xl ${step.bg} flex items-center justify-center mb-6 md:hidden`}>
                         <step.icon className={`w-7 h-7 ${step.color}`} />
                      </div>
                      <h3 className="text-2xl font-bold text-foreground mb-3">{step.title}</h3>
                      <p className="text-muted-foreground text-lg leading-relaxed">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-24 text-center">
          <Link href="/upload">
            <Button size="lg" className="rounded-full bg-foreground text-background hover:bg-foreground/90 h-14 px-10 text-lg shadow-xl hover:scale-105 transition-transform">
              Try It Now <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>

      </div>
    </div>
  );
}