import dns from 'dns';
import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { auth } from '@clerk/nextjs/server';
import { db } from '@/lib/db';
import { createClient } from '@supabase/supabase-js';

// Force IPv4 first to prevent Windows undici fetch failed errors with Google APIs
try {
  dns.setDefaultResultOrder('ipv4first');
} catch (e) {
  console.warn("Could not set DNS default result order:", e);
}

// Initialize the Gemini API
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');

// Initialize Supabase Client
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const supabase = createClient(supabaseUrl, supabaseKey);

export async function POST(req: NextRequest) {
  try {
    let userId = "guest-mobile-user";
    try {
      const authResult = await auth();
      if (authResult?.userId) {
        userId = authResult.userId;
      }
    } catch (e) {
      console.log("Clerk auth skipped for phone LAN access");
    }

    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json(
        { error: 'Gemini API key is not configured. Please add GEMINI_API_KEY to your .env.local file.' },
        { status: 500 }
      );
    }

    const formData = await req.formData();
    const file = formData.get('image') as File | null;

    if (!file) {
      return NextResponse.json({ error: 'No image provided' }, { status: 400 });
    }

    // Convert File to Base64
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const base64Data = buffer.toString('base64');
    const mimeType = file.type;

    // Use gemini-3.5-flash for reliable, high-speed vision appraisal
    const model = genAI.getGenerativeModel({ model: 'gemini-3.5-flash' });

    const prompt = `
      You are an expert electronics appraiser. Analyze this image of a device.
      Respond strictly in the following JSON format without any markdown wrappers or additional text:
      {
        "deviceName": "Detected name of the device (e.g. iPhone 13 Pro, Dell XPS 15)",
        "category": "Smartphone, Laptop, Tablet, etc.",
        "condition": "Excellent, Good, Moderate, or Damaged based on visible scratches, cracks, or wear",
        "conditionDetails": "A brief 1-sentence description of the visible condition (e.g. 'Minor scratches on back panel. Screen is flawless.')",
        "estimatedValue": "An estimated resale value in Indian Rupees (₹), just the number without commas (e.g. 35000)",
        "lowEstimate": "Lowest expected value in INR (e.g. 30000)",
        "highEstimate": "Highest expected value in INR (e.g. 40000)",
        "recommendation": "Sell, Repair, Donate, or Recycle based on condition and value",
        "recommendationReason": "A brief 1-sentence explanation of why this recommendation makes sense"
      }
      If the image is not of an electronic device, return:
      {
        "error": "Image does not appear to be a recognizable electronic device."
      }
    `;

    const imageParts = [
      {
        inlineData: {
          data: base64Data,
          mimeType
        },
      },
    ];

    let result;
    let retries = 3;
    let lastErr;
    while (retries > 0) {
      try {
        result = await model.generateContent([prompt, ...imageParts]);
        break;
      } catch (err: any) {
        lastErr = err;
        retries--;
        if (retries === 0) throw err;
        console.warn(`Gemini generateContent attempt failed (${err.message}), retrying in 1s...`);
        await new Promise(res => setTimeout(res, 1000));
      }
    }
    const responseText = result!.response.text();
    
    // Clean up potential markdown from the response
    const cleanedJsonString = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
    
    let analysisData;
    try {
      analysisData = JSON.parse(cleanedJsonString);
    } catch (parseError) {
      console.error("Failed to parse Gemini response:", responseText);
      return NextResponse.json({ error: 'Failed to parse AI response' }, { status: 500 });
    }

    if (analysisData.error) {
      return NextResponse.json({ error: analysisData.error }, { status: 400 });
    }

    // Upload image to Supabase Storage
    let imageUrl = null;
    if (supabaseUrl && supabaseKey) {
      try {
        const fileName = `${userId}-${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('appraisals')
          .upload(fileName, buffer, {
            contentType: mimeType,
            upsert: false
          });
        
        if (uploadError) {
          console.error("Supabase upload error:", uploadError);
        } else if (uploadData?.path) {
          const { data: publicUrlData } = supabase.storage
            .from('appraisals')
            .getPublicUrl(uploadData.path);
          imageUrl = publicUrlData.publicUrl;
        }
      } catch (uploadErr) {
        console.error("Failed to upload to Supabase:", uploadErr);
      }
    }

    // Save to Database
    try {
      const savedAppraisal = await db.appraisal.create({
        data: {
          userId,
          deviceName: analysisData.deviceName || 'Unknown Device',
          category: analysisData.category,
          condition: analysisData.condition || 'Unknown',
          conditionDetails: analysisData.conditionDetails,
          estimatedValue: parseFloat(analysisData.estimatedValue) || 0,
          lowEstimate: analysisData.lowEstimate ? parseFloat(analysisData.lowEstimate) : null,
          highEstimate: analysisData.highEstimate ? parseFloat(analysisData.highEstimate) : null,
          recommendation: analysisData.recommendation || 'Unknown',
          recommendationReason: analysisData.recommendationReason,
          imageUrl: imageUrl, // Save the Supabase public URL
        }
      });
      // Optionally return the ID if the frontend needs it
      analysisData.id = savedAppraisal.id;
    } catch (dbError) {
      console.error("Failed to save to database:", dbError);
      // We don't fail the whole request just because DB save failed
    }

    return NextResponse.json({ data: analysisData });
    
  } catch (error: any) {
    console.error('Error analyzing image:', error, error.cause);
    const errorMessage = error.cause?.message || error.message || 'An error occurred during image analysis';
    return NextResponse.json(
      { error: errorMessage },
      { status: 500 }
    );
  }
}
