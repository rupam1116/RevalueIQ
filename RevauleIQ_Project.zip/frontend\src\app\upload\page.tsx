"use client";
import { useRouter } from "next/navigation";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { UploadCloud, CheckCircle, Smartphone, Camera, LineChart, Wrench, RefreshCw, X, ShieldCheck, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import Link from "next/link";

type UploadState = "idle" | "uploading" | "analyzing" | "results";

const compressImage = async (file: File): Promise<File> => {
  return new Promise((resolve) => {
    if (!file.type.startsWith('image/') || file.type === 'image/svg+xml' || file.type === 'image/gif') {
      return resolve(file);
    }
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const maxDimension = 1200;
        let width = img.width;
        let height = img.height;
        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        } else if (file.size < 1024 * 1024) {
          return resolve(file);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(file);
        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob(
          (blob) => {
            if (!blob) return resolve(file);
            const compressedFile = new File([blob], file.name.replace(/\.[^/.]+$/, "") + ".jpg", {
              type: 'image/jpeg',
              lastModified: Date.now(),
            });
            resolve(compressedFile);
          },
          'image/jpeg',
          0.82
        );
      };
      img.onerror = () => resolve(file);
    };
    reader.onerror = () => resolve(file);
  });
};

export default function UploadPage() {
  const [uploadState, setUploadState] = useState<UploadState>("idle");
  const [progress, setProgress] = useState(0);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setPreviewUrl(URL.createObjectURL(file));
      setError(null);
      setUploadState("uploading");
      uploadAndAnalyze(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setPreviewUrl(URL.createObjectURL(file));
      setError(null);
      setUploadState("uploading");
      uploadAndAnalyze(file);
    }
  };

  const uploadAndAnalyze = async (file: File) => {
    try {
      const compressedFile = await compressImage(file);
      const formData = new FormData();
      formData.append('image', compressedFile);

      // Start simulated progress for uploading phase
      let currentProgress = 0;
      const progressInterval = setInterval(() => {
        currentProgress += 5;
        if (currentProgress >= 100) {
          clearInterval(progressInterval);
          setUploadState("analyzing");
          startAnalyzingProgress();
        } else {
          setProgress(currentProgress);
        }
      }, 50);

      // Actual fetch
      const response = await fetch('/api/analyze', {
        method: 'POST',
        body: formData,
      });

      const json = await response.json();
      
      if (!response.ok) {
        throw new Error(json.error || 'Failed to analyze image');
      }

      setAnalysisResult(json.data);
      
      // The analysis might finish before our simulated progress is done,
      // but we wait for it to naturally progress to results state to keep the UX smooth.
      
    } catch (err: any) {
      console.error(err);
      setError(err.message);
      setUploadState("idle");
      setProgress(0);
    }
  };

  let analysisIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const startAnalyzingProgress = () => {
    setProgress(0);
    analysisIntervalRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 98) {
          return prev; // hold at 98% until fetch completes
        }
        return prev + 2;
      });
    }, 150);
  };

  useEffect(() => {
    // When in analyzing state and we have the result, transition to the detailed report page
    if (uploadState === "analyzing" && analysisResult) {
      setProgress(100);
      if (analysisIntervalRef.current) clearInterval(analysisIntervalRef.current);
      
      setTimeout(() => {
        if (analysisResult.id) {
          router.push(`/dashboard/${analysisResult.id}`);
        } else {
          setUploadState("results"); // fallback if no ID for some reason
        }
      }, 500);
    }
  }, [uploadState, analysisResult, router]);

  useEffect(() => {
    return () => {
      if (analysisIntervalRef.current) clearInterval(analysisIntervalRef.current);
    }
  }, []);

  const resetFlow = () => {
    setUploadState("idle");
    setProgress(0);
    setPreviewUrl(null);
    setAnalysisResult(null);
    setError(null);
  };

  return (
    <div className="min-h-screen pt-24 pb-12 relative overflow-hidden flex items-center justify-center">
      {/* Background Gradients matching homepage */}
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/5 via-background to-background"></div>
      <div className="absolute top-1/4 -left-1/4 w-[500px] h-[500px] bg-teal-500/10 rounded-full blur-[100px] -z-10 mix-blend-multiply"></div>
      <div className="absolute top-1/3 -right-1/4 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[120px] -z-10 mix-blend-multiply"></div>

      <div className="container mx-auto px-4 max-w-4xl relative z-10">
        
        <div className="text-center mb-10 animate-in fade-in slide-in-from-top-4 duration-500">
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4 font-poppins">
            Analyze Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Device</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Upload a clear image of your electronics. Our AI will automatically verify the model, assess damage, and predict its value.
          </p>
        </div>

        <div className="glass-card rounded-3xl border border-white/20 dark:border-white/10 shadow-2xl bg-white/60 dark:bg-slate-900/60 backdrop-blur-2xl p-6 md:p-10 relative overflow-hidden min-h-[500px] flex flex-col items-center justify-center animate-in fade-in zoom-in-95 duration-700">
          <AnimatePresence mode="wait">
            
            {/* IDLE STATE */}
            {uploadState === "idle" && (
              <motion.div
                key="idle"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="w-full flex flex-col items-center"
              >
                {error && (
                  <div className="w-full max-w-2xl bg-red-500/10 border border-red-500/50 text-red-600 dark:text-red-400 p-4 rounded-xl mb-6 flex items-center gap-3">
                    <AlertCircle className="w-5 h-5 flex-shrink-0" />
                    <p className="text-sm font-medium">{error}</p>
                  </div>
                )}
                <div 
                  className="w-full max-w-2xl border-2 border-dashed border-primary/30 rounded-3xl p-12 hover:border-primary hover:bg-primary/5 transition-all duration-300 cursor-pointer flex flex-col items-center justify-center text-center group"
                  onDragOver={handleDragOver}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input 
                    type="file" 
                    className="hidden" 
                    ref={fileInputRef} 
                    accept="image/*"
                    onChange={handleFileSelect}
                  />
                  <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <UploadCloud className="w-10 h-10 text-primary" />
                  </div>
                  <h3 className="text-2xl font-semibold mb-2">Click or Drag & Drop</h3>
                  <p className="text-muted-foreground mb-6">SVG, PNG, JPG or GIF (max. 10MB)</p>
                  
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1"><ShieldCheck className="w-4 h-4 text-teal-500" /> Secure</span>
                    <span className="flex items-center gap-1"><Camera className="w-4 h-4 text-primary" /> High-Res Preferred</span>
                  </div>
                </div>
              </motion.div>
            )}

            {/* UPLOADING STATE */}
            {uploadState === "uploading" && (
              <motion.div
                key="uploading"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="w-full max-w-md flex flex-col items-center text-center"
              >
                <div className="w-24 h-24 mb-6 rounded-2xl overflow-hidden border-2 border-primary/20 shadow-lg relative">
                  {previewUrl && <img src={previewUrl} alt="Preview" className="w-full h-full object-cover" />}
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <RefreshCw className="w-8 h-8 text-white animate-spin" />
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2">Uploading Image...</h3>
                <p className="text-muted-foreground text-sm mb-6">Transferring your device photo securely.</p>
                <Progress value={progress} className="w-full h-2 mb-2" />
                <p className="text-sm font-medium">{progress}%</p>
              </motion.div>
            )}

            {/* ANALYZING STATE */}
            {uploadState === "analyzing" && (
              <motion.div
                key="analyzing"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="w-full max-w-md flex flex-col items-center text-center"
              >
                <div className="relative w-32 h-32 mb-8">
                  {/* Radar/Scanning Animation */}
                  <div className="absolute inset-0 border-4 border-primary/20 rounded-full"></div>
                  <div className="absolute inset-0 border-4 border-primary rounded-full border-t-transparent animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Smartphone className="w-12 h-12 text-primary" />
                  </div>
                </div>
                
                <h3 className="text-2xl font-bold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-primary to-teal-400">
                  AI Analysis in Progress
                </h3>
                <p className="text-sm text-muted-foreground mb-6">Gemini is analyzing your image...</p>
                
                <div className="space-y-3 w-full text-left mt-2 mb-8">
                  <div className="flex items-center gap-3">
                    {progress > 20 ? <CheckCircle className="w-5 h-5 text-teal-500" /> : <RefreshCw className="w-5 h-5 text-muted-foreground animate-spin" />}
                    <span className={progress > 20 ? "text-foreground font-medium" : "text-muted-foreground"}>Verifying Device Model...</span>
                  </div>
                  <div className="flex items-center gap-3">
                    {progress > 50 ? <CheckCircle className="w-5 h-5 text-teal-500" /> : progress > 20 ? <RefreshCw className="w-5 h-5 text-primary animate-spin" /> : <div className="w-5 h-5 rounded-full border-2 border-muted-foreground/30" />}
                    <span className={progress > 50 ? "text-foreground font-medium" : progress > 20 ? "text-primary font-medium" : "text-muted-foreground"}>Detecting Surface Damage...</span>
                  </div>
                  <div className="flex items-center gap-3">
                    {progress > 90 ? <CheckCircle className="w-5 h-5 text-teal-500" /> : progress > 50 ? <RefreshCw className="w-5 h-5 text-primary animate-spin" /> : <div className="w-5 h-5 rounded-full border-2 border-muted-foreground/30" />}
                    <span className={progress > 90 ? "text-foreground font-medium" : progress > 50 ? "text-primary font-medium" : "text-muted-foreground"}>Estimating Market Value...</span>
                  </div>
                </div>
                
                <Progress value={progress} className="w-full h-2 bg-primary/10" />
              </motion.div>
            )}

            {/* RESULTS STATE */}
            {uploadState === "results" && (
              <motion.div
                key="results"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full"
              >
                <div className="flex items-center justify-between border-b border-border/50 pb-6 mb-8">
                  <div className="flex items-center gap-6">
                    <div className="relative">
                      <div className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-primary/20 shadow-md">
                        {previewUrl && <img src={previewUrl} alt="Analyzed Device" className="w-full h-full object-cover" />}
                      </div>
                      <div className="absolute -bottom-3 -right-3 bg-teal-500 text-white rounded-full p-1.5 shadow-lg">
                        <CheckCircle className="w-5 h-5" />
                      </div>
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold">{analysisResult?.deviceName || 'Unknown Device'}</h2>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                        <span className="px-2 py-0.5 bg-primary/10 text-primary rounded-full">{analysisResult?.category || 'Electronics'}</span>
                      </div>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" onClick={resetFlow} className="rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
                    <X className="w-5 h-5" />
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="bg-white/50 dark:bg-slate-800/50 p-6 rounded-2xl border border-border/50 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-muted-foreground mb-3">
                        <Camera className="w-5 h-5" />
                        <span className="font-medium">Condition</span>
                      </div>
                      <div className="text-3xl font-bold mb-2">{analysisResult?.condition || 'N/A'}</div>
                      <p className="text-sm text-muted-foreground">{analysisResult?.conditionDetails}</p>
                    </div>
                    <div className={`mt-4 pt-4 border-t border-border/50 text-sm font-medium flex items-center gap-1 ${
                      analysisResult?.condition === 'Excellent' || analysisResult?.condition === 'Good' 
                        ? 'text-teal-600 dark:text-teal-400' 
                        : 'text-amber-600 dark:text-amber-400'
                    }`}>
                      <CheckCircle className="w-4 h-4" /> Visual Check Complete
                    </div>
                  </div>

                  <div className="bg-white/50 dark:bg-slate-800/50 p-6 rounded-2xl border border-border/50 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-muted-foreground mb-3">
                        <LineChart className="w-5 h-5 text-primary" />
                        <span className="font-medium">Est. Value</span>
                      </div>
                      <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent mb-2">
                        ₹{analysisResult?.estimatedValue ? Number(analysisResult.estimatedValue).toLocaleString('en-IN') : '0'}
                      </div>
                      <p className="text-sm text-muted-foreground">Based on current market data.</p>
                    </div>
                    <div className="mt-4 pt-4 border-t border-border/50">
                      <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-1.5 mb-1">
                        <div className="bg-gradient-to-r from-primary to-accent h-1.5 rounded-full" style={{ width: '50%' }}></div>
                      </div>
                      <div className="text-xs text-muted-foreground flex justify-between">
                        <span>Low: ₹{analysisResult?.lowEstimate ? Number(analysisResult.lowEstimate).toLocaleString('en-IN') : '0'}</span>
                        <span>High: ₹{analysisResult?.highEstimate ? Number(analysisResult.highEstimate).toLocaleString('en-IN') : '0'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-primary/10 to-teal-500/10 dark:from-primary/20 dark:to-teal-500/20 p-6 rounded-2xl border border-primary/20 flex flex-col justify-between relative overflow-hidden">
                    <div className="absolute -right-4 -top-4 text-primary/10">
                      <StarIcon className="w-32 h-32" />
                    </div>
                    <div className="relative z-10">
                      <div className="flex items-center gap-2 text-primary font-semibold mb-3 uppercase tracking-wider text-sm">
                        AI Recommendation
                      </div>
                      <div className="text-4xl font-extrabold text-foreground mb-2">{analysisResult?.recommendation || 'Unknown'}</div>
                      <p className="text-sm font-medium text-muted-foreground">
                        {analysisResult?.recommendationReason}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-10">
                  <Link href="/marketplace" className="w-full sm:w-auto">
                    <Button size="lg" className="w-full rounded-full bg-gradient-to-r from-primary to-accent text-white shadow-xl shadow-primary/25 hover:scale-105 transition-transform h-14 px-8 text-lg font-semibold">
                      Proceed to Sell
                    </Button>
                  </Link>
                  <Button size="lg" variant="outline" className="w-full sm:w-auto rounded-full h-14 px-8 text-lg border-2 hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors">
                    View Repair Options
                  </Button>
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

// Reusable Star icon since it wasn't imported from lucide
function StarIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
  );
}