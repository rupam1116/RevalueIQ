import RepairShopsPage from "@/app/repair-shops/page";

export default function RepairPage() {
  return <RepairShopsPage />;
}