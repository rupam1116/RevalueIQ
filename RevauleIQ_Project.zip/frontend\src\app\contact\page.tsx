"use client";

import { Mail, MessageSquare, PhoneCall } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function ContactPage() {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const firstName = formData.get("First Name");
    const lastName = formData.get("Last Name");
    const email = formData.get("Email");
    const message = formData.get("Message");

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          firstName,
          lastName,
          email,
          message,
        })
      });

      const data = await response.json();

      if (response.ok && data.success) {
        alert("Thank you! Your message has been sent directly to your email.");
        form.reset();
      } else {
        alert(data.error || "Oops! Make sure your Resend API Key is set in .env.local.");
      }
    } catch (error) {
      alert("Something went wrong. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen pt-28 pb-20 bg-slate-50 dark:bg-slate-950">
      <div className="container mx-auto px-4 md:px-8 max-w-5xl">
        
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold font-poppins tracking-tight text-foreground">
            Get in Touch
          </h1>
          <p className="text-xl text-muted-foreground leading-relaxed mt-4">
            Have questions about our API, enterprise pricing, or partnerships? Our team is ready to help.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <a href="https://mail.google.com/mail/?view=cm&fs=1&to=rupamxy@gmail.com" target="_blank" rel="noopener noreferrer" className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-border shadow-sm text-center hover:shadow-md hover:border-primary/30 transition-all block group">
            <div className="w-12 h-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Mail className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-bold text-foreground mb-2 group-hover:text-primary transition-colors">Email Us</h3>
            <p className="text-muted-foreground text-sm mb-4">For general inquiries</p>
            <span className="font-medium text-primary group-hover:underline">rupamxy@gmail.com</span>
          </a>
          <a href="/support" className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-border shadow-sm text-center hover:shadow-md hover:border-primary/30 transition-all block group">
            <div className="w-12 h-12 mx-auto bg-accent/10 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <MessageSquare className="w-6 h-6 text-accent" />
            </div>
            <h3 className="font-bold text-foreground mb-2 group-hover:text-primary transition-colors">Support</h3>
            <p className="text-muted-foreground text-sm mb-4">For account or technical help</p>
            <span className="font-medium text-primary group-hover:underline">Visit Support Center</span>
          </a>
          <a href="tel:+917997268281" className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-border shadow-sm text-center hover:shadow-md hover:border-primary/30 transition-all block group">
            <div className="w-12 h-12 mx-auto bg-teal-500/10 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <PhoneCall className="w-6 h-6 text-teal-500" />
            </div>
            <h3 className="font-bold text-foreground mb-2 group-hover:text-primary transition-colors">Sales</h3>
            <p className="text-muted-foreground text-sm mb-4">For enterprise pricing</p>
            <span className="font-medium text-primary group-hover:underline">+91 7997268281</span>
          </a>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 md:p-12 border border-border shadow-lg max-w-3xl mx-auto">
          <h2 className="text-2xl font-bold text-foreground mb-6">Send us a message</h2>
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">First Name</label>
                <input required type="text" name="First Name" className="w-full px-4 py-3 rounded-xl border border-border bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="Jane" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Last Name</label>
                <input required type="text" name="Last Name" className="w-full px-4 py-3 rounded-xl border border-border bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="Doe" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Email</label>
              <input required type="email" name="Email" className="w-full px-4 py-3 rounded-xl border border-border bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="jane@gmail.com" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Message</label>
              <textarea required rows={4} name="Message" className="w-full px-4 py-3 rounded-xl border border-border bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="How can we help you?"></textarea>
            </div>
            <Button type="submit" disabled={isSubmitting} className="w-full rounded-full h-12 text-lg">
              {isSubmitting ? "Sending..." : "Send Message"}
            </Button>
          </form>
        </div>

      </div>
    </div>
  );
}