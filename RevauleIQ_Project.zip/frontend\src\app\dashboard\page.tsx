import { auth, currentUser } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Smartphone, LineChart, Package, Calendar } from "lucide-react";

export default async function DashboardPage() {
  const { userId } = await auth();
  const user = await currentUser();

  if (!userId) {
    redirect("/login");
  }

  // Fetch recent appraisals from DB
  const appraisals = await db.appraisal.findMany({
    where: {
      OR: [
        { userId: userId },
        { userId: "guest-mobile-user" },
      ],
    },
    orderBy: { createdAt: 'desc' },
  });

  const totalValue = appraisals.reduce((acc, curr) => acc + curr.estimatedValue, 0);
  const averageValue = appraisals.length > 0 ? totalValue / appraisals.length : 0;

  return (
    <div className="container mx-auto px-4 py-12 min-h-screen">
      <div className="flex flex-col md:flex-row items-center justify-between mb-12 gap-4">
        <div>
          <h1 className="text-4xl font-bold tracking-tight mb-2">My Dashboard</h1>
          <p className="text-muted-foreground text-lg">Welcome back, {user?.firstName || 'User'}! Here's your appraisal history.</p>
        </div>
        <div className="flex items-center gap-4 bg-white/50 dark:bg-slate-900/50 p-2 pr-4 rounded-full border border-border/50 shadow-sm">
          <Avatar className="h-10 w-10 border-2 border-primary/20">
            <AvatarImage src={user?.imageUrl} alt="Profile" />
            <AvatarFallback>{user?.firstName?.charAt(0) || 'U'}</AvatarFallback>
          </Avatar>
          <div className="text-sm">
            <p className="font-semibold">{user?.fullName}</p>
            <p className="text-muted-foreground text-xs">{user?.primaryEmailAddress?.emailAddress}</p>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20 shadow-sm hover:shadow-md transition-all">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Evaluated</CardTitle>
            <Package className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{appraisals.length}</div>
            <p className="text-xs text-muted-foreground mt-1">Devices scanned</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-teal-500/5 to-teal-500/10 border-teal-500/20 shadow-sm hover:shadow-md transition-all">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Portfolio Value</CardTitle>
            <LineChart className="h-4 w-4 text-teal-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-teal-500">
              ₹{totalValue.toLocaleString('en-IN')}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Total estimated worth</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-accent/5 to-accent/10 border-accent/20 shadow-sm hover:shadow-md transition-all">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Avg. Device Value</CardTitle>
            <Smartphone className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              ₹{Math.round(averageValue).toLocaleString('en-IN')}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Across all scans</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity Table */}
      <Card className="shadow-lg border-border/50 bg-white/40 dark:bg-slate-900/40 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="text-xl">Recent Appraisals</CardTitle>
          <CardDescription>A history of devices you have scanned and their estimated market value.</CardDescription>
        </CardHeader>
        <CardContent>
          {appraisals.length === 0 ? (
            <div className="text-center py-12 flex flex-col items-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 text-primary">
                <Smartphone className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-semibold mb-2">No devices appraised yet</h3>
              <p className="text-muted-foreground mb-6">Head over to the upload page to scan your first device!</p>
            </div>
          ) : (
            <div className="rounded-md border border-border/50 overflow-hidden">
              <Table>
                <TableHeader className="bg-slate-50 dark:bg-slate-800/50">
                  <TableRow>
                    <TableHead>Device</TableHead>
                    <TableHead>Condition</TableHead>
                    <TableHead>Recommendation</TableHead>
                    <TableHead className="text-right">Est. Value</TableHead>
                    <TableHead className="text-right">Date</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {appraisals.map((item) => (
                    <TableRow key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                      <TableCell className="font-medium">
                        <div>
                          <p>{item.deviceName}</p>
                          <p className="text-xs text-muted-foreground">{item.category}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          item.condition === 'Excellent' || item.condition === 'Good' 
                            ? 'bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-400'
                            : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
                        }`}>
                          {item.condition}
                        </span>
                      </TableCell>
                      <TableCell>{item.recommendation}</TableCell>
                      <TableCell className="text-right font-semibold text-primary">
                        ₹{item.estimatedValue.toLocaleString('en-IN')}
                      </TableCell>
                      <TableCell className="text-right text-muted-foreground text-sm">
                        {new Date(item.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <a href={`/dashboard/${item.id}`} className="text-sm font-medium text-primary hover:underline">
                          View Details
                        </a>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}