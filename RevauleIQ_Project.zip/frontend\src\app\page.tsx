"use client";

import { ArrowRight, Cpu, Scan, CheckCircle, LineChart, Wrench, Shield, Recycle, HandHeart, Upload, Smartphone, Battery, Star, Camera } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

const stats = [
  { label: "Products Analysed", value: "50K+" },
  { label: "AI Accuracy", value: "98%" },
  { label: "Products Saved", value: "30K+" },
  { label: "E-Waste Reduced", value: "120 Tons" },
];

const features = [
  { icon: Scan, title: "AI Product Verification", description: "Instantly verify electronics category and make." },
  { icon: Camera, title: "Computer Vision Damage Detection", description: "Identify scratches, cracks, and defects." },
  { icon: LineChart, title: "ML Price Prediction", description: "Predict real-time market and resale value." },
  { icon: Cpu, title: "Generative AI Repair Advisor", description: "Get repair guides and estimated costs." },
  { icon: HandHeart, title: "Donation Matching", description: "Connect with NGOs to donate seamlessly." },
  { icon: Recycle, title: "Carbon Savings Dashboard", description: "Track your environmental impact." },
];

const steps = [
  { icon: Upload, title: "Upload Images", description: "Snap photos of your device from multiple angles." },
  { icon: Shield, title: "AI Verification", description: "Our AI verifies the product model and specifications." },
  { icon: Scan, title: "Damage Detection", description: "Computer vision spots scratches, cracks, and dents." },
  { icon: LineChart, title: "Price Prediction", description: "Machine learning estimates the current resale value." },
  { icon: Wrench, title: "Repair Advisory", description: "Generative AI suggests repair steps and estimated costs." },
  { icon: Star, title: "Decision Engine", description: "Get the best recommendation: Repair, Sell, Donate, or Recycle." },
];

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-32 pb-20 lg:pt-48 lg:pb-32">
        {/* Background Gradients */}
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
        <div className="absolute top-1/4 -left-1/4 w-[500px] h-[500px] bg-teal-500/20 rounded-full blur-[100px] -z-10 mix-blend-multiply"></div>
        <div className="absolute top-1/3 -right-1/4 w-[600px] h-[600px] bg-primary/20 rounded-full blur-[120px] -z-10 mix-blend-multiply"></div>
        
        <div className="container mx-auto px-4 md:px-6 lg:px-8 text-center">
          <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700 fill-mode-both">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium border border-primary/20 mb-4">
              <span className="flex h-2 w-2 rounded-full bg-primary animate-pulse"></span>
              Introducing RevalueIQ Platform 1.0
            </div>
            
            <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-foreground font-poppins leading-[1.1]">
              Give Your Electronics a <br className="hidden md:block" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-teal-400 to-accent">Second Life with AI</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Upload your product. Our AI analyzes its condition, predicts resale value, provides repair guidance, and recommends whether to <strong className="text-foreground">Repair, Sell, Replace, Donate, or Recycle.</strong>
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <Link href="/upload" className="w-full sm:w-auto">
                <Button size="lg" className="w-full rounded-full bg-gradient-to-r from-primary to-accent text-white shadow-xl shadow-primary/25 hover:scale-105 transition-transform h-14 px-8 text-lg">
                  Analyze Product <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="/marketplace" className="w-full sm:w-auto">
                <Button size="lg" variant="outline" className="w-full rounded-full h-14 px-8 text-lg border-2 hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors">
                  Explore Marketplace
                </Button>
              </Link>
            </div>
          </div>

          {/* Floating UI Cards (Illustration) */}
          <div className="mt-24 relative max-w-5xl mx-auto h-[400px]">
            <div className="absolute left-1/2 -translate-x-1/2 top-0 w-full max-w-3xl glass-card rounded-2xl border border-white/20 dark:border-white/10 shadow-2xl bg-white/40 dark:bg-slate-900/40 backdrop-blur-xl p-6 animate-in fade-in slide-in-from-bottom-8 duration-1000 fill-mode-both delay-150">
              <div className="flex items-center justify-between border-b border-border/50 pb-4 mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center">
                    <Smartphone className="w-8 h-8 text-primary" />
                  </div>
                  <div className="text-left">
                    <h3 className="font-semibold text-lg">iPhone 13 Pro</h3>
                    <p className="text-sm text-muted-foreground">Category: Smartphone</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-accent">₹35,000 - ₹45,000</div>
                  <p className="text-xs text-muted-foreground">Est. Resale Value</p>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-white/50 dark:bg-slate-800/50 p-4 rounded-xl border border-border/50">
                  <div className="text-primary mb-2"><CheckCircle className="w-5 h-5" /></div>
                  <div className="font-medium">Condition</div>
                  <div className="text-2xl font-bold mt-1">85%</div>
                </div>
                <div className="bg-white/50 dark:bg-slate-800/50 p-4 rounded-xl border border-border/50">
                  <div className="text-accent mb-2"><Battery className="w-5 h-5" /></div>
                  <div className="font-medium">Battery Health</div>
                  <div className="text-2xl font-bold mt-1">92%</div>
                </div>
                <div className="bg-white/50 dark:bg-slate-800/50 p-4 rounded-xl border border-border/50">
                  <div className="text-teal-500 mb-2"><LineChart className="w-5 h-5" /></div>
                  <div className="font-medium">AI Decision</div>
                  <div className="text-xl font-bold mt-1 text-teal-600 dark:text-teal-400">Sell</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="border-y border-border bg-slate-50/50 dark:bg-slate-900/50">
        <div className="container mx-auto px-4 md:px-6 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center hover:scale-105 transition-transform duration-300">
                <div className="text-4xl md:text-5xl font-bold text-foreground font-poppins mb-2">{stat.value}</div>
                <div className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 relative">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <h2 className="text-3xl md:text-4xl font-bold font-poppins">Powered by Next-Gen AI</h2>
            <p className="text-muted-foreground text-lg">
              RevalueIQ utilizes state-of-the-art machine learning and computer vision to bring transparency and efficiency to the circular economy.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="group p-8 rounded-3xl bg-white dark:bg-slate-900 border border-border hover:shadow-xl hover:border-primary/20 hover:-translate-y-1 transition-all duration-300 relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                <Link href="/features" className="relative z-10 block cursor-pointer">
                  <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <feature.icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 bg-slate-50 dark:bg-slate-900 relative">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <h2 className="text-3xl md:text-4xl font-bold font-poppins">How RevalueIQ Works</h2>
            <p className="text-muted-foreground text-lg">
              A seamless, 6-step process to maximize value and minimize environmental impact.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 relative">
            {/* Connecting lines for desktop */}
            <div className="hidden lg:block absolute top-12 left-20 right-20 h-0.5 bg-border -z-10"></div>
            
            {steps.map((step, index) => (
              <Link href="/upload" key={index} className="relative flex flex-col items-center text-center p-6 group cursor-pointer">
                <div className="flex flex-col items-center w-full group-hover:-translate-y-1 transition-transform duration-300">
                  <div className="w-24 h-24 rounded-full bg-white dark:bg-slate-800 border-4 border-slate-50 dark:border-slate-900 shadow-lg flex items-center justify-center mb-6 z-10 relative group-hover:scale-110 transition-transform duration-300 group-hover:border-primary/20">
                    <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-bold text-sm">
                      {index + 1}
                    </div>
                    <step.icon className="w-10 h-10 text-primary group-hover:text-accent transition-colors" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </div>
              </Link>
            ))}
          </div>
          
          <div className="mt-16 text-center">
            <Link href="/upload">
              <Button size="lg" className="rounded-full h-14 px-8 text-lg bg-foreground text-background hover:bg-foreground/90 transition-colors">
                Start the Process Now
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
