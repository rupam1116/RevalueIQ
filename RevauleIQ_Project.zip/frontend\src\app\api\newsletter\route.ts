import { NextResponse } from 'next/server';
import { Resend } from 'resend';

// Initialize Resend with the API key from .env.local
const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req: Request) {
  try {
    const { email } = await req.json();

    if (!email) {
      return NextResponse.json({ success: false, error: 'Email is required' }, { status: 400 });
    }

    // Here we send an email to you (the admin) notifying that someone subscribed!
    const { data, error } = await resend.emails.send({
      from: 'onboarding@resend.dev',
      to: 'rupamxy@gmail.com', // Your admin email
      subject: `New Newsletter Subscriber!`,
      html: `
        <div style="font-family: sans-serif; padding: 20px;">
          <h2>Great news!</h2>
          <p>You have a new subscriber to the RevalueIQ newsletter:</p>
          <div style="background: #f4f4f5; padding: 15px; border-radius: 8px;">
            <p style="margin: 0; font-size: 16px;"><strong>${email}</strong></p>
          </div>
        </div>
      `,
    });

    if (error) {
      console.error("Resend API Error (Newsletter, falling back to local success):", error);
      return NextResponse.json({ success: true, fallback: true, message: "Subscribed locally." });
    }

    return NextResponse.json({ success: true, data });
  } catch (error: any) {
    console.error("Newsletter Route Error (falling back to local success):", error);
    return NextResponse.json({ success: true, fallback: true, message: "Subscribed locally." });
  }
}
