import Link from "next/link";
import { ArrowLeft, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CommunityPage() {
  return (
    <div className="min-h-screen pt-28 pb-20 bg-slate-50 dark:bg-slate-950">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link href="/support" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary transition-colors mb-2">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Support
            </Link>
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground">Community Forum</h1>
            <p className="text-muted-foreground mt-2 text-lg">Connect with other users, share repair tips, and ask questions.</p>
          </div>
        </div>

        {/* Coming Soon Placeholder */}
        <div className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-xl rounded-3xl border border-border p-12 text-center shadow-sm min-h-[400px] flex flex-col items-center justify-center relative overflow-hidden group">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-accent/10 via-transparent to-transparent opacity-50"></div>
          
          <div className="w-24 h-24 bg-accent/10 rounded-full flex items-center justify-center mb-6 relative z-10">
            <MessageCircle className="w-12 h-12 text-accent" />
          </div>
          <h2 className="text-3xl font-bold mb-4 relative z-10 text-foreground">Community Forum Coming Soon!</h2>
          <p className="text-muted-foreground max-w-lg mx-auto text-lg mb-8 relative z-10">
            We are working hard to build a space for our community to thrive. Soon, you will be able to share your sustainable repair stories and get help from experts.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 relative z-10">
            <Link href="/support">
              <Button size="lg" className="rounded-full px-8 h-12 bg-accent hover:bg-accent/90 text-white shadow-md hover:scale-105 transition-transform">Go Back</Button>
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
