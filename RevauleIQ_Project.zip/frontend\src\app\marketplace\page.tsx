import Link from "next/link";
import { ArrowLeft, ShoppingCart, Search, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function MarketplacePage() {
  return (
    <div className="min-h-screen pt-28 pb-20 bg-slate-50 dark:bg-slate-950">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link href="/dashboard" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary transition-colors mb-2">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
            </Link>
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground">RevalueIQ Marketplace</h1>
            <p className="text-muted-foreground mt-2 text-lg">Buy and sell verified refurbished electronics with confidence.</p>
          </div>
          <Button className="hidden md:flex rounded-full px-6 shadow-sm">
            <ShoppingCart className="w-4 h-4 mr-2" />
            Sell a Device
          </Button>
        </div>

        {/* Coming Soon Placeholder */}
        <div className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-xl rounded-3xl border border-border p-12 text-center shadow-sm min-h-[400px] flex flex-col items-center justify-center relative overflow-hidden group">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent opacity-50"></div>
          
          <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-6 relative z-10">
            <ShoppingCart className="w-12 h-12 text-primary" />
          </div>
          <h2 className="text-3xl font-bold mb-4 relative z-10 text-foreground">Coming Very Soon!</h2>
          <p className="text-muted-foreground max-w-lg mx-auto text-lg mb-8 relative z-10">
            We are currently building the marketplace infrastructure to connect buyers and sellers securely. 
            Once launched, your AI-appraised devices can be listed with a single click.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 relative z-10">
            <Button size="lg" className="rounded-full px-8 h-12 bg-gradient-to-r from-primary to-accent hover:scale-105 transition-transform text-white">Join Waitlist</Button>
            <Link href="/upload">
              <Button size="lg" variant="outline" className="rounded-full px-8 h-12 bg-white dark:bg-slate-800">
                Appraise Another Device
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}