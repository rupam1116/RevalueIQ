import Image from "next/link";
import { Leaf, Target, Users, Zap } from "lucide-react";

export default function AboutPage() {
  return (
    <div className="min-h-screen pt-28 pb-20 bg-slate-50 dark:bg-slate-950">
      
      {/* Hero Section */}
      <section className="container mx-auto px-4 md:px-8 max-w-5xl mb-24">
        <div className="text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium border border-primary/20">
            <Leaf className="w-4 h-4" /> Our Mission
          </div>
          <h1 className="text-4xl md:text-6xl font-bold font-poppins tracking-tight text-foreground">
            Pioneering the <span className="text-primary">Circular Economy</span>
          </h1>
          <p className="text-xl text-muted-foreground leading-relaxed max-w-3xl mx-auto">
            At RevalueIQ, we believe that technology shouldn't cost the Earth. We are building the intelligence layer for global e-waste management, empowering consumers and businesses to make sustainable decisions.
          </p>
        </div>
      </section>

      {/* The Problem & Solution */}
      <section className="container mx-auto px-4 md:px-8 max-w-6xl mb-24">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-foreground">The 50 Million Ton Problem</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Every year, over 50 million metric tons of e-waste are generated globally, with only 17% being formally recycled. Millions of perfectly functional devices are thrown away simply because the process of grading, repairing, or finding a buyer is too complex and untrustworthy.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              We started RevalueIQ to eliminate this friction. By leveraging advanced Computer Vision and AI, we bring absolute transparency and standardization to the secondary electronics market.
            </p>
          </div>
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-border shadow-lg grid grid-cols-2 gap-6 relative overflow-hidden">
             <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 blur-3xl rounded-full"></div>
             <div className="space-y-2">
                <div className="text-4xl font-extrabold text-primary">50M+</div>
                <div className="text-sm font-medium text-slate-500">Tons of E-Waste Annually</div>
             </div>
             <div className="space-y-2">
                <div className="text-4xl font-extrabold text-accent">17%</div>
                <div className="text-sm font-medium text-slate-500">Global Recycling Rate</div>
             </div>
             <div className="space-y-2">
                <div className="text-4xl font-extrabold text-teal-500">3x</div>
                <div className="text-sm font-medium text-slate-500">Faster Appraisals</div>
             </div>
             <div className="space-y-2">
                <div className="text-4xl font-extrabold text-orange-500">100%</div>
                <div className="text-sm font-medium text-slate-500">Objective Grading</div>
             </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="bg-white dark:bg-slate-900 border-y border-border py-24">
        <div className="container mx-auto px-4 md:px-8 max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground">Our Core Values</h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-2xl flex items-center justify-center">
                <Target className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Transparency First</h3>
              <p className="text-muted-foreground">We eliminate information asymmetry. Our AI models provide unbiased, objective valuations that both buyers and sellers can trust.</p>
            </div>
            
            <div className="text-center space-y-4">
              <div className="w-16 h-16 mx-auto bg-accent/10 rounded-2xl flex items-center justify-center">
                <Leaf className="w-8 h-8 text-accent" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Environmental Impact</h3>
              <p className="text-muted-foreground">Every line of code we write is aimed at extending the lifecycle of electronics and keeping toxic materials out of landfills.</p>
            </div>

            <div className="text-center space-y-4">
              <div className="w-16 h-16 mx-auto bg-teal-500/10 rounded-2xl flex items-center justify-center">
                <Zap className="w-8 h-8 text-teal-500" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Continuous Innovation</h3>
              <p className="text-muted-foreground">We constantly train our models on millions of new data points to ensure our appraisals represent the true cutting edge of technology.</p>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}